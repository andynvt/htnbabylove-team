function alert() {
    //    $(".modal-dialog").attr("data-dismiss", "modal");
    $(".alert").fadeIn(700);
    setTimeout(function () {
        $(".alert").fadeOut(700);
    }, 2000)
}
